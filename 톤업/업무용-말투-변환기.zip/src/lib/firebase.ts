import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut } from "firebase/auth";
import { initializeFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyDQtoXS4tE7Rrxlu1FvKUHqHk3KG7AQqqQ",
  authDomain: "micro-limiter-5gbcx.firebaseapp.com",
  projectId: "micro-limiter-5gbcx",
  storageBucket: "micro-limiter-5gbcx.firebasestorage.app",
  messagingSenderId: "422443027538",
  appId: "1:422443027538:web:1caa2cd851220e56f1238b"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const googleProvider = new GoogleAuthProvider();

// Initialize Firestore with the database ID provided in config
const db = initializeFirestore(app, {}, "ai-studio-801eadcd-b9db-4382-a938-1a21d7b9dea9");

export { auth, googleProvider, db, signInWithPopup, signOut };
